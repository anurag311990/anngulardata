export const Env = {
    production: false,
    apiEndpoint: 'http://localhost:5000'
}