import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'; 
import { AppComponent } from './app.component';
import { routes, declareRouts} from './app-routing.module'
import { FormsModule } from '@angular/forms'

 
import { loginService} from '../app/Services/loginServices'
import { errorService} from '../app/Services/errorHandling'

import {   
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatRippleModule,
  MatCardModule,
  MatCheckboxModule, MatToolbarModule, MatSidenavModule, MatIconModule, MatListModule,MatGridListModule,
  
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MyNavComponent } from './my-nav/my-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    declareRouts
     
  ],
  imports: [
    FormsModule,
    BrowserModule,     
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
    NoopAnimationsModule,
    MatCardModule,
    MatCheckboxModule,
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatGridListModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],

  providers: [loginService,errorService],
  bootstrap: [AppComponent]
})
export class AppModule { }
