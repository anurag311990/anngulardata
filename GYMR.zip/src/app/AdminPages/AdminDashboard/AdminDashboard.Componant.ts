import { Component, OnInit } from '@angular/core';
 

@Component({
  selector: 'admin-dashboard',
  templateUrl: './AdminDashboard.component.html' 
})
export class AdminDashboardComponent implements OnInit {
    ngOnInit() {
    
    }
  
}