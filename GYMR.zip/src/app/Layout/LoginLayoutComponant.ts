import { Component, OnInit } from '@angular/core';
import {loginService} from '../Services/loginServices'
import {LoginModel} from '../Models/LoginModel'


@Component({
  selector: 'app-app-layout',
  templateUrl: './LoginLayout.html',  
})
export class LoginLayoutComponent implements OnInit 
{
  public _loginModel = new LoginModel() ;
  constructor(public _loginService: loginService ) {
    
   }
  ngOnInit() {
    this._loginModel.Username = "Admin"
    this._loginModel.Password = "123456"
    this._loginService.validateLoginUser(this._loginModel);
     
  }

}