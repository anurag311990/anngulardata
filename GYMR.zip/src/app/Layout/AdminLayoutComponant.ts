import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-app-layout',
  templateUrl: './AdminLayout.html',  
})
export class AdminLayoutComponent implements OnInit 
{

 
  constructor() { }

  ngOnInit() {
  
  }

}