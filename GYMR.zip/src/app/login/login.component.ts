import { Component, OnInit } from '@angular/core';
import { LoginModel } from'../Models/loginModel'
import { loginService } from '../Services/loginServices'
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public  loginModel = new LoginModel(); 
  constructor(private _loginService : loginService, private _route:Router) { 
    
  }

  ngOnInit() {
    
  }

  public onSubmit(){
    this._loginService.validateLoginUser(this.loginModel).subscribe(
      data=>{
        if(data.Usertype === 1)
        {
          this._route.navigate(['/Admin']);
        }
      }
    )
  }

}
