import {Injectable} from '@angular/core'
 
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import {LoginModel} from '../Models/LoginModel'
import { catchError, tap } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs'
import {errorService} from '../Services/errorHandling'
import { Env } from  '../Common/ProjectConfiguration'


@Injectable({
    providedIn:'root'
})

export class loginService{

    private apiUrl : string;

    constructor(private _http: HttpClient , private _errorService : errorService ){
    }
   
    public validateLoginUser(loginmodel: LoginModel)
    {
        this.apiUrl = Env.apiEndpoint +'/api/Authenticate/';
        let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        return this._http.post<any>(this.apiUrl, loginmodel, { headers: headers })
            .pipe(tap(data =>
            {
                console.log(data);
                if (data.Token != null)
                {
                    if (data.Usertype == "2") {
                        // store username and jwt token in local storage to keep user logged in between page refreshes
                        localStorage.setItem('currentUser', JSON.stringify({ username: loginmodel.Username, token: data.Token }));
                    }
                    else if (data.Usertype == "1") {
                        // store username and jwt token in local storage to keep user logged in between page refreshes
                        localStorage.setItem('AdminUser', JSON.stringify({ username: loginmodel.Username, token: data.Token }));
                    }
                    // return true to indicate successful login
                    return data;
                } else {
                    // return false to indicate failed login
                    return null;
                }
            }),
                catchError((error: HttpErrorResponse) => {
                    this._errorService.handleError(error);
                    return throwError("");
                })
                
            );
     }
    

    LogoutUser() {
        localStorage.removeItem('currentUser');
    }

  
}