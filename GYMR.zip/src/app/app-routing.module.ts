
import { Routes } from '@angular/router';
import {LoginLayoutComponent} from './Layout/LoginLayoutComponant'
import{LoginComponent} from './login/login.component'
import{ AdminLayoutComponent } from './Layout/AdminLayoutComponant'
import { AdminDashboardComponent } from '../app/AdminPages/AdminDashboard/AdminDashboard.Componant'

export const routes: Routes = [
  { 
    path: 'User', 
    component: LoginLayoutComponent, 
    children:[
    { path: 'Login', component: LoginComponent },
    ] 
  },
   {
     path:'Admin',
     component: AdminLayoutComponent,
     children:[
       {path:'', component : AdminDashboardComponent}
     ]
   }
];  

export const declareRouts = [
  LoginLayoutComponent,
  LoginComponent,
  AdminLayoutComponent,
  AdminDashboardComponent
]

