import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginLayoutComponent} from './Layout/LoginLayoutComponant'
import{LoginComponent} from './login/login.component'

const routes: Routes = [
  { path: 'Login', component: LoginLayoutComponent, children:[
    { path: '', component: LoginComponent },
  ] },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)
    
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
