import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-app-layout',
  templateUrl: './LoginLayout.html',  
})
export class AdminLayoutComponent implements OnInit 
{

 
  constructor() { }

  ngOnInit() {
  
  }

}